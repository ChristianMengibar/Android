package com.example.tareacalculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText numberOne;
    private EditText numberTwo;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.numberOne = findViewById(R.id.et1);
        this.numberTwo = findViewById(R.id.et2);
        this.result = findViewById(R.id.tv4);
    }

    public void aceptar(View v) {
        if (numberOne.getText().toString().isEmpty() || numberTwo.getText().toString().isEmpty()){
            result.setText("Debes insertar los dos numeros");
        }else{
            if (v.getId() == R.id.bt1) {
                result.setText(suma(Double.parseDouble(numberOne.getText().toString()), Double.parseDouble(numberTwo.getText().toString())) + "");
            } else if (v.getId() == R.id.bt2) {
                result.setText(resta(Double.parseDouble(numberOne.getText().toString()), Double.parseDouble(numberTwo.getText().toString())) + "");
            } else if (v.getId() == R.id.bt3) {
                result.setText(multiplicacion(Double.parseDouble(numberOne.getText().toString()), Double.parseDouble(numberTwo.getText().toString())) + "");
            } else if (v.getId() == R.id.bt4) {
                result.setText(division(Double.parseDouble(numberOne.getText().toString()), Double.parseDouble(numberTwo.getText().toString())) + "");

            }

        }
    }

    public void reset(View v) {
        numberOne.setText("");
        numberTwo.setText("");
        result.setText("");
    }

    public double suma(double a, double b) {
        return a + b;
    }

    public double resta(double a, double b) {
        return a - b;
    }

    public double multiplicacion(double a, double b) {
        return a * b;
    }

    public double division(double a, double b) {
        return a / b;
    }
}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    private Button bCas1,bCas2,bCas3,bCas4,bCas5,bCas6,bCas7,bCas8,bCas9,bJugador1;
    private RadioGroup rgDificultad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rgDificultad = (RadioGroup) findViewById(R.id.rgDificultad);
        bJugador1 = (Button) findViewById(R.id.bJugador1);
        bCas1 = (Button) findViewById(R.id.bCas1);
        bCas2 = (Button) findViewById(R.id.bCas2);
        bCas3 = (Button) findViewById(R.id.bCas3);
        bCas4 = (Button) findViewById(R.id.bCas4);
        bCas5 = (Button) findViewById(R.id.bCas5);
        bCas6 = (Button) findViewById(R.id.bCas6);
        bCas7 = (Button) findViewById(R.id.bCas7);
        bCas8 = (Button) findViewById(R.id.bCas8);
        bCas9 = (Button) findViewById(R.id.bCas9);
        rgDificultad.setVisibility(View.GONE);
    }

    public void cargarDificultad(View v){
        if(bJugador1.isPressed()){
            if(rgDificultad.getVisibility() == View.VISIBLE){
                rgDificultad.setVisibility(View.GONE);
            } else {
                rgDificultad.setVisibility(View.VISIBLE);
            }
        }
    }

    public void CargarSimbolo(Button b){
        b.setText("X");
    }
    public void CargarSimbolo1(View v){
        CargarSimbolo(bCas1);
    }
    public void CargarSimbolo2(View v){
        CargarSimbolo(bCas2);
    }
    public void CargarSimbolo3(View v){
        CargarSimbolo(bCas3);
    }
    public void CargarSimbolo4(View v){
        CargarSimbolo(bCas4);
    }
    public void CargarSimbolo5(View v){
        CargarSimbolo(bCas5);
    }
    public void CargarSimbolo6(View v){
        CargarSimbolo(bCas6);
    }
    public void CargarSimbolo7(View v){
        CargarSimbolo(bCas7);
    }
    public void CargarSimbolo8(View v){
        CargarSimbolo(bCas8);
    }
    public void CargarSimbolo9(View v){
        CargarSimbolo(bCas9);
    }

}
package com.example.menuproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        //menu.add(0, 1, Menu.NONE, "Nuevo");
        //menu.add(0, 2, Menu.NONE, "Abrir");

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.mi_nuevo:
                Toast.makeText(this, "Has pulsado la opción Nuevo", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.mi_abrir:
                Toast.makeText(this, "Has pulsado la opción Abrir", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.mi_acrobat:
                Toast.makeText(this, "Has pulsado la opción Acrobat", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.mi_pdf:
                Toast.makeText(this, "Has pulsado la opción PDF", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
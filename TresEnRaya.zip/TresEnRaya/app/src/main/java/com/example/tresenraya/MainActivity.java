package com.example.tresenraya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button boton1;
    Button boton2;
    Button boton3;
    Button boton4;
    Button boton5;
    Button boton6;
    Button boton7;
    Button boton8;
    Button boton9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
boton1 = (Button) findViewById(R.id.btn1);
boton2 = (Button) findViewById(R.id.btn2);
boton3 = (Button) findViewById(R.id.btn3);
boton4 = (Button) findViewById(R.id.btn4);
boton5 = (Button) findViewById(R.id.btn5);
boton6 = (Button) findViewById(R.id.btn6);
boton7 = (Button) findViewById(R.id.btn7);
boton8 = (Button) findViewById(R.id.btn8);
boton9 = (Button) findViewById(R.id.btn9);
    }

    public void boton1(View view){

            boton1.setText("X");

    }
    public void boton2(View view){
        boton2.setText("X");
    }
    public void boton3(View view){
        boton3.setText("X");
    }
    public void boton4(View view){
        boton4.setText("X");
    }
    public void boton5(View view){
        boton5.setText("X");
    }
    public void boton6(View view){
        boton6.setText("X");
    }
    public void boton7(View view){
        boton7.setText("X");
    }
    public void boton8(View view){
        boton8.setText("X");
    }
    public void boton9(View view){
        boton9.setText("X");
    }
    public void borrar(View view){
        boton1.setText("");
        boton2.setText("");
        boton3.setText("");
        boton4.setText("");
        boton5.setText("");
        boton6.setText("");
        boton7.setText("");
        boton8.setText("");
        boton9.setText("");
    }
}
package com.example.actionbarjavayxml;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageView imagenFruta;
    private TextView recibirDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
        getDatos();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_frutas,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            initComponents();
            switch (item.getItemId()){
                case R.id.appleSub_Golden:
                    Toast.makeText(this, "Ha elegido Manzana Golden", Toast.LENGTH_SHORT).show();
                    imagenFruta.setImageResource(R.drawable.golden);
                    return true;

                case R.id.appleSub_PinkLady:
                    Toast.makeText(this, "Ha elegido Pink Lady", Toast.LENGTH_SHORT).show();
                    imagenFruta.setImageResource(R.drawable.pink_lady);
                    return true;
                case R.id.mainMenu_Banana:
                    Toast.makeText(this,"Ha elegido Platanos",Toast.LENGTH_SHORT).show();
                    imagenFruta.setImageResource(R.drawable.platano);
                    return true;

                case R.id.peraSub_Conferencia:
                    Toast.makeText(this, "Ha elegido Pera Conferencia", Toast.LENGTH_SHORT).show();
                    imagenFruta.setImageResource(R.drawable.pera_conferencia);
                    return true;
                case R.id.peraSub_Limonera:
                    Toast.makeText(this, "Ha elegido Pera Limonera", Toast.LENGTH_SHORT).show();
                    imagenFruta.setImageResource(R.drawable.pera_limonera);
                    return true;
                case R.id.mainMenu_Next:
                    Intent goToSecondAct = new Intent(this,MainActivity2.class);
                    startActivity(goToSecondAct);
            }
        return super.onOptionsItemSelected(item);
    }


    public void initComponents(){
        imagenFruta = findViewById(R.id.img_Fruta);
        recibirDatos = findViewById(R.id.tv_MainAct_Datos);
    }

    public void getDatos(){
        recibirDatos = findViewById(R.id.tv_MainAct_Datos);
        recibirDatos.setText(getIntent().getStringExtra(MainActivity2.DATOS));
    }

}
package com.example.actionbarjavayxml;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    protected static final String DATOS = "com.example.actionbarjavayxml.datos";

    private EditText introDatos;
    private boolean enterDataActivated;

    public void initComponents(){
        introDatos = findViewById(R.id.et_SecAct_IntroName);
        introDatos.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        initComponents();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        SubMenu submenuAnteriorAct = menu.addSubMenu(Menu.NONE,1,Menu.NONE,"Volver a Frutas");
        menu.add(Menu.NONE,2,Menu.NONE,"Introducir Datos");
        submenuAnteriorAct.add(Menu.NONE,12,Menu.NONE,R.string.anteriorActividad);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        initComponents();
        Intent goActivityFruits = new Intent(this,MainActivity.class);
        switch (item.getItemId()){
            case 12:
                if(enterDataActivated){
                    if(introDatos.getText().toString().equals("")){
                        Toast.makeText(this, "Introduce un nombre", Toast.LENGTH_SHORT).show();
                    } else {
                        goActivityFruits.putExtra(DATOS,introDatos.getText().toString());
                        startActivity(goActivityFruits);
                    }
                } else {
                    startActivity(goActivityFruits);
                }
                return true;
            case 2:
                enterDataActivated = true;
                introDatos.setVisibility(View.VISIBLE);

        }

        return super.onOptionsItemSelected(item);
    }
}
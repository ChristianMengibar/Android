package com.example.ejercicio1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private TextView ma1_tvPulsar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ma1_tvPulsar = (TextView) findViewById(R.id.ma1_tvPulsar);
        registerForContextMenu(ma1_tvPulsar);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle("Choose a color");

        menu.add(0, 1, 0, "Yellow");
        menu.add(0, 2, 0, "Gray");
        menu.add(0, 3, 0, "Cyan");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        ConstraintLayout constraintLayout = (ConstraintLayout) findViewById(R.id.cl_mainActivity);

        if (item.getTitle() == "Yellow") {
            constraintLayout.setBackgroundColor(Color.YELLOW);
        } else if (item.getTitle() == "Gray") {
            constraintLayout.setBackgroundColor(Color.GRAY);
        } else if (item.getTitle() == "Cyan") {
            constraintLayout.setBackgroundColor(Color.CYAN);
        }

        return true;
    }
}
package com.example.contador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private Button btSuma;
    private Button btResta;
    private Button btReset;
    private TextView tvContador;
    private TextView tvNum1;
    private EditText etContador;
    private ToggleButton tgActivado;
    private CheckBox cbNegativos;
    private int counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btSuma = (Button) findViewById(R.id.btSuma);
        btResta = (Button) findViewById(R.id.btRestaid);
        btReset = (Button) findViewById(R.id.btReset);
        tvContador = (TextView) findViewById(R.id.tvContador);
        tvNum1 = (TextView) findViewById(R.id.tvNum1);
        etContador = (EditText) findViewById(R.id.etContador);
        tgActivado = (ToggleButton) findViewById(R.id.tgActivado);
        cbNegativos = (CheckBox) findViewById(R.id.cbNegativos);

        tvNum1.setText(Integer.toString(counter));

        counter = 0;

        etContador.setText("1");
    }

    public void sumar(View view) {
        int numero1 = (Integer.parseInt(etContador.getText().toString()));

        if (numero1 <= 0) {
            Toast.makeText(this, "EL número debe ser mayor que 0. Intentelo otra vez ", Toast.LENGTH_SHORT).show();
        } else {
            counter = counter + numero1;

            tvNum1.setText(Integer.toString(counter));
        }
    }

    public void restar(View view) {
        int numero1 = (Integer.parseInt(etContador.getText().toString()));

        if (numero1 <= 0) {
            Toast.makeText(this, "EL número debe ser mayor que 0. Intentelo otra vez ", Toast.LENGTH_SHORT).show();
        } else if (numero1 > 0) {
            counter = counter - numero1;
        }
        if (counter < 0) {
            counter = 0;
            Toast.makeText(this, "El numero no puede ser menor de 0.", Toast.LENGTH_SHORT).show();
            tvNum1.setText(Integer.toString(counter));
        } else
            tvNum1.setText(Integer.toString(counter));
    }

    public void resetear(View view) {
        etContador.setText("0");
    }

    public void visibilidad(View view) {
        if (tgActivado.isChecked()) {
            Toast.makeText(this, "Funciones desactivadas.", Toast.LENGTH_SHORT).show();
            btReset.setVisibility(View.INVISIBLE);
            etContador.setVisibility(View.INVISIBLE);
            cbNegativos.setVisibility(View.INVISIBLE);
        } else {
            Toast.makeText(this, "Funciones activadas.", Toast.LENGTH_SHORT).show();
            btReset.setVisibility(View.VISIBLE);
            etContador.setVisibility(View.VISIBLE);
            cbNegativos.setVisibility(View.VISIBLE);
        }
    }

    public void visibilidadResta(View view) {
        if (cbNegativos.isChecked()) {
            Toast.makeText(this, "Boton invisible.", Toast.LENGTH_SHORT).show();
            btResta.setVisibility(View.INVISIBLE);
        } else {
            Toast.makeText(this, "Boton visible.", Toast.LENGTH_SHORT).show();
            btResta.setVisibility(View.VISIBLE);
        }
    }
}
package com.example.tareaordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity7 extends AppCompatActivity {

    private TextView tv_categoria7;
    private TextView tv_codigo7;
    private TextView tv_producto7;

    public void volver (View view) {
        Intent volver = new Intent(this, MainActivity.class);
        startActivity(volver);
    }

    public void volverVolver (View view) {
        Intent volver = new Intent(this, MainActivity2.class);
        startActivity(volver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity2.EXTRA_CATEGORIA);
        String codigo = intent.getStringExtra(MainActivity2.EXTRA_CODIGO);
        String producto = intent.getStringExtra(MainActivity2.EXTRA_PRODUCTO1);

        tv_categoria7 = (TextView) findViewById(R.id.tv_categoria7);
        tv_codigo7 = (TextView) findViewById(R.id.tv_codigo7);
        tv_producto7 = (TextView) findViewById(R.id.tv_producto7);

        tv_categoria7.setText(categoria);
        tv_codigo7.setText(codigo);
        tv_producto7.setText(producto);
    }

    public void cesta (View view) {
        Toast.makeText(this, "Añadido correctamente a la cesta.", Toast.LENGTH_SHORT).show();
    }
}
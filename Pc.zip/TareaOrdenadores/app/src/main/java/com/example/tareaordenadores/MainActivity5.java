package com.example.tareaordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {

    private TextView tv_categoria5;
    private TextView tv_codigo5;
    private TextView tv_producto5;

    public void volver (View view) {
        Intent volver = new Intent(this, MainActivity.class);
        startActivity(volver);
    }

    public void volverVolver (View view) {
        Intent volver = new Intent(this, MainActivity3.class);
        startActivity(volver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity3.EXTRA_CATEGORIA);
        String codigo = intent.getStringExtra(MainActivity3.EXTRA_CODIGO);
        String producto = intent.getStringExtra(MainActivity3.EXTRA_PRODUCTO2);

        tv_categoria5 = (TextView) findViewById(R.id.tv_categoria5);
        tv_codigo5 = (TextView) findViewById(R.id.tv_codigo5);
        tv_producto5 = (TextView) findViewById(R.id.tv_producto5);

        tv_categoria5.setText(categoria);
        tv_codigo5.setText(codigo);
        tv_producto5.setText(producto);
    }

    public void cesta (View view) {
        Toast.makeText(this, "Añadido correctamente a la cesta.", Toast.LENGTH_SHORT).show();
    }
}
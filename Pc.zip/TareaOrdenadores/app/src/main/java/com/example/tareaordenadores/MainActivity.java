package com.example.tareaordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private ImageButton ib_portatiles;
    private ImageButton ib_sobremesa;
    private Button bt_portatiles;
    private Button bt_sobremesa;

    protected boolean invisbles;

    protected final static String EXTRA_PORTATILES = "com.example.tareaordenadores.portatiles";
    protected final static String EXTRA_PORTATILES_CODIGO = "com.example.tareaordenadores.codigoportatil";
    protected final static String EXTRA_SOBREMESA = "com.example.tareaordenadores.sobremesa";
    protected final static String EXTRA_SOBREMESA_CODIGO = "com.example.tareaordenadores.codigosobremesa";

    public void portatiles (View view) {
        Intent volver = new Intent(this, MainActivity2.class);
        startActivity(volver);
    }

    public void sobremesa (View view) {
        Intent volver = new Intent(this, MainActivity3.class);
        startActivity(volver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ib_portatiles = (ImageButton) findViewById(R.id.ib_portatiles);
        ib_sobremesa = (ImageButton) findViewById(R.id.ib_sobremesa);
        bt_portatiles = (Button) findViewById(R.id.bt_portatiles);
        bt_sobremesa = (Button) findViewById(R.id.bt_sobremesa);

        ib_portatiles.setVisibility(View.INVISIBLE);
        ib_sobremesa.setVisibility(View.INVISIBLE);
        bt_portatiles.setVisibility(View.INVISIBLE);
        bt_sobremesa.setVisibility(View.INVISIBLE);

        invisbles = true;
    }

    public void cambiarPortatiles(View view) {
        Intent pantallaPortatiles = new Intent(this, MainActivity2.class);

        pantallaPortatiles.putExtra(EXTRA_PORTATILES_CODIGO, "10000");
        pantallaPortatiles.putExtra(EXTRA_PORTATILES, "Portatiles");

        startActivity(pantallaPortatiles);
    }

    public void cambiarSobremesa(View view) {
        Intent pantallaSobremesa = new Intent(this, MainActivity3.class);

        pantallaSobremesa.putExtra(EXTRA_SOBREMESA_CODIGO, "20000");
        pantallaSobremesa.putExtra(EXTRA_SOBREMESA, "Sobremesa");

        startActivity(pantallaSobremesa);
    }

    public void mostrar(View view) {
        if (invisbles) {
            ib_portatiles.setVisibility(View.VISIBLE);
            ib_sobremesa.setVisibility(View.VISIBLE);
            bt_portatiles.setVisibility(View.VISIBLE);
            bt_sobremesa.setVisibility(View.VISIBLE);

            invisbles = false;

            Toast.makeText(this, "Opciones mostradas correctamente.", Toast.LENGTH_SHORT).show();

        } else {
            ib_portatiles.setVisibility(View.INVISIBLE);
            ib_sobremesa.setVisibility(View.INVISIBLE);
            bt_portatiles.setVisibility(View.INVISIBLE);
            bt_sobremesa.setVisibility(View.INVISIBLE);

            invisbles = true;

            Toast.makeText(this, "Opciones ocultadas correctamente.", Toast.LENGTH_SHORT).show();
        }
    }
}
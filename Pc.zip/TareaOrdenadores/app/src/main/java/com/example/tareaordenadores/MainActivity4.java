package com.example.tareaordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {

    private TextView tv_categoria4;
    private TextView tv_codigo4;
    private TextView tv_producto4;

    public void volver (View view) {
        Intent volver = new Intent(this, MainActivity.class);
        startActivity(volver);
    }

    public void volverVolver (View view) {
        Intent volver = new Intent(this, MainActivity3.class);
        startActivity(volver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity3.EXTRA_CATEGORIA);
        String codigo = intent.getStringExtra(MainActivity3.EXTRA_CODIGO);
        String producto = intent.getStringExtra(MainActivity3.EXTRA_PRODUCTO2);

        tv_categoria4 = (TextView) findViewById(R.id.tv_categoria4);
        tv_codigo4 = (TextView) findViewById(R.id.tv_codigo4);
        tv_producto4 = (TextView) findViewById(R.id.tv_producto4);

        tv_categoria4.setText(categoria);
        tv_codigo4.setText(codigo);
        tv_producto4.setText(producto);
    }

    public void cesta (View view) {
        Toast.makeText(this, "Añadido correctamente a la cesta.", Toast.LENGTH_SHORT).show();
    }
}
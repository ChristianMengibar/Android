package com.example.tareaordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity3 extends AppCompatActivity {

    protected final static String EXTRA_CATEGORIA = "com.example.tareaordenadores.categoria2";
    protected final static String EXTRA_CODIGO = "com.example.tareaordenadores.codigo2";
    protected final static String EXTRA_PRODUCTO2 = "com.example.tareaordenadores.producto2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }

    public void sobremesa1 (View view) {
        Intent volver = new Intent(this, MainActivity4.class);
        startActivity(volver);
    }

    public void sobremesa2 (View view) {
        Intent volver = new Intent(this, MainActivity5.class);
        startActivity(volver);
    }

    public void volver (View view) {
        Intent volver = new Intent(this, MainActivity.class);
        startActivity(volver);
    }

    public void verDetallePrimero (View view) {
        Intent primero = new Intent(this, MainActivity4.class);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity.EXTRA_SOBREMESA);
        String codigo = intent.getStringExtra(MainActivity.EXTRA_SOBREMESA_CODIGO);

        primero.putExtra(EXTRA_CATEGORIA, categoria);
        primero.putExtra(EXTRA_CODIGO, codigo);
        primero.putExtra(EXTRA_PRODUCTO2, "20000-1");

        startActivity(primero);
    }

    public void verDetalleSegundo (View view) {
        Intent segundo = new Intent(this, MainActivity5.class);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity.EXTRA_SOBREMESA);
        String codigo = intent.getStringExtra(MainActivity.EXTRA_SOBREMESA_CODIGO);

        segundo.putExtra(EXTRA_CATEGORIA, categoria);
        segundo.putExtra(EXTRA_CODIGO, codigo);
        segundo.putExtra(EXTRA_PRODUCTO2, "20000-2");

        startActivity(segundo);
    }
}
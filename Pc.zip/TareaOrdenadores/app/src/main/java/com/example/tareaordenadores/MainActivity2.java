package com.example.tareaordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity2 extends AppCompatActivity {

    protected final static String EXTRA_CATEGORIA = "com.example.tareaordenadores.categoria1";
    protected final static String EXTRA_CODIGO = "com.example.tareaordenadores.codigo1";
    protected final static String EXTRA_PRODUCTO1 = "com.example.tareaordenadores.producto1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void portatiles1 (View view) {
        Intent volver = new Intent(this, MainActivity6.class);
        startActivity(volver);
    }

    public void portatiles2 (View view) {
        Intent volver = new Intent(this, MainActivity7.class);
        startActivity(volver);
    }

    public void volver (View view) {
        Intent volver = new Intent(this, MainActivity.class);
        startActivity(volver);
    }

    public void verDetallePrimero (View view) {
        Intent primero = new Intent(this, MainActivity6.class);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity.EXTRA_PORTATILES);
        String codigo = intent.getStringExtra(MainActivity.EXTRA_PORTATILES_CODIGO);

        primero.putExtra(EXTRA_CATEGORIA, categoria);
        primero.putExtra(EXTRA_CODIGO, codigo);
        primero.putExtra(EXTRA_PRODUCTO1, "10000-1");

        startActivity(primero);
    }

    public void verDetalleSegundo (View view) {
        Intent segundo = new Intent(this, MainActivity7.class);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity.EXTRA_PORTATILES);
        String codigo = intent.getStringExtra(MainActivity.EXTRA_PORTATILES_CODIGO);

        segundo.putExtra(EXTRA_CATEGORIA, categoria);
        segundo.putExtra(EXTRA_CODIGO, codigo);
        segundo.putExtra(EXTRA_PRODUCTO1, "10000-2");

        startActivity(segundo);
    }
}
package com.example.tareaordenadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity {

    private TextView tv_categoria6;
    private TextView tv_codigo6;
    private TextView tv_producto6;

    public void volver (View view) {
        Intent volver = new Intent(this, MainActivity.class);
        startActivity(volver);
    }

    public void volverVolver (View view) {
        Intent volver = new Intent(this, MainActivity2.class);
        startActivity(volver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        Intent intent = getIntent();

        String categoria = intent.getStringExtra(MainActivity2.EXTRA_CATEGORIA);
        String codigo = intent.getStringExtra(MainActivity2.EXTRA_CODIGO);
        String producto = intent.getStringExtra(MainActivity2.EXTRA_PRODUCTO1);

        tv_categoria6 = (TextView) findViewById(R.id.tv_categoria6);
        tv_codigo6 = (TextView) findViewById(R.id.tv_codigo6);
        tv_producto6 = (TextView) findViewById(R.id.tv_producto6);

        tv_categoria6.setText(categoria);
        tv_codigo6.setText(codigo);
        tv_producto6.setText(producto);
    }

    public void cesta (View view) {
        Toast.makeText(this, "Añadido correctamente a la cesta.", Toast.LENGTH_SHORT).show();
    }
}
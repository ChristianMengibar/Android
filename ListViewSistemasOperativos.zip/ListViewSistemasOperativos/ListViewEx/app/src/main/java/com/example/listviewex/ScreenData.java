package com.example.listviewex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ScreenData extends AppCompatActivity {

    private TextView tvNombre, tvVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_data);
        init();
    }

    private void init(){
        tvNombre = findViewById(R.id.tv_showSSOO);
        tvVersion = findViewById(R.id.tvshowVersion);
        getData();
    }

    private void getData(){
        Intent intent = getIntent();
        String nombre = intent.getStringExtra(MainActivity.SELECT_NAME);
        String version = intent.getStringExtra(MainActivity.SELECT_VERSION);
        tvNombre.setText(nombre);
        tvVersion.setText(version);
    }

}
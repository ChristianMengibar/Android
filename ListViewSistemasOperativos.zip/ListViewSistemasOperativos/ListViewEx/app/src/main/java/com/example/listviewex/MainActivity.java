package com.example.listviewex;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ListView lv_SSOO;
    private String[] SSOO;
    private RadioGroup rg_Version;
    private RadioButton rb_Version1, rb_Version2, rb_Version3;
    private EditText et_Otro;
    private String optionSelected, nameSSOO;

    protected final static String SELECT_NAME = "com.example.listviewex.nombre";
    protected final static String SELECT_VERSION = "com.example.listviewex.version";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init(){
        initComponents();
        initVisibility();
        initListView();
    }
    private void initComponents(){
        lv_SSOO = findViewById(R.id.lv_SSOO);
        SSOO = new String[]{"Windows", "iOS", "Ubuntu", "Android", "Otros"};
        rg_Version = findViewById(R.id.rgVersion);
        rb_Version1 = findViewById(R.id.rbVersion1);
        rb_Version2 = findViewById(R.id.rbVersion2);
        rb_Version3 = findViewById(R.id.rbVersion3);
        et_Otro = findViewById(R.id.et_Otro);
    }

    private void initVisibility(){
        rg_Version.setVisibility(View.GONE);
        et_Otro.setVisibility(View.GONE);
    }

    private void cleanOptions(){
        rg_Version.clearCheck();
        et_Otro.setText("");
    }
    private void showSelectedToast(String ssooName){
        Toast.makeText(this, "Ha seleccionado: " + ssooName, Toast.LENGTH_SHORT).show();
    }

    private void initListView(){
        ArrayAdapter adapter_frutas = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,SSOO);
        lv_SSOO.setAdapter(adapter_frutas);

        lv_SSOO.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    cleanOptions();
                        nameSSOO = adapterView.getItemAtPosition(i).toString();
                    showSelectedToast(nameSSOO);
                    et_Otro.setVisibility(View.GONE);
                    rg_Version.setVisibility(View.VISIBLE);
                    rb_Version1.setText("Windows Vista");
                    rb_Version2.setText("Windows 7");
                    rb_Version3.setText("Windows 10");
                } else if (i == 1) {
                    cleanOptions();
                    nameSSOO = adapterView.getItemAtPosition(i).toString();
                    showSelectedToast(nameSSOO);
                    et_Otro.setVisibility(View.GONE);
                    rg_Version.setVisibility(View.VISIBLE);
                    rb_Version1.setText("Mac OS X 10.0 (Cheetah)");
                    rb_Version2.setText("Mac OS X 10.3 (Panther)");
                    rb_Version3.setText("Mac OS X 10.7 (Lion)");
                } else if (i == 2){
                    cleanOptions();
                    nameSSOO = adapterView.getItemAtPosition(i).toString();
                    showSelectedToast(nameSSOO);
                    et_Otro.setVisibility(View.GONE);
                    rg_Version.setVisibility(View.VISIBLE);
                    rb_Version1.setText("Ubuntu GNOME");
                    rb_Version2.setText("Xubuntu");
                    rb_Version3.setText("Ubuntu Kylin");
                }else if (i == 3){
                    cleanOptions();
                    nameSSOO = adapterView.getItemAtPosition(i).toString();
                    showSelectedToast(nameSSOO);
                    et_Otro.setVisibility(View.GONE);
                    rg_Version.setVisibility(View.VISIBLE);
                    rb_Version1.setText("Gingerbread");
                    rb_Version2.setText("Honeycomb");
                    rb_Version3.setText("Jelly Bean");
                }else if (i == 4){
                    cleanOptions();
                    nameSSOO = adapterView.getItemAtPosition(i).toString();
                    showSelectedToast(nameSSOO);
                    rg_Version.setVisibility(View.GONE);
                    et_Otro.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private String whoSelected(){
        if (rb_Version1.isChecked()) {
            optionSelected = rb_Version1.getText().toString();
        } else if (rb_Version2.isChecked()){
            optionSelected = rb_Version2.getText().toString();
        }else if (rb_Version3.isChecked()){
            optionSelected = rb_Version3.getText().toString();
        }else {
            optionSelected = et_Otro.getText().toString();
        }
        return optionSelected;
    }

    public void sendData(View view){
        String data = whoSelected();
        data = data.trim();
        if (data.isEmpty()){
            Toast.makeText(this, "Debe marcar alguna opcion", Toast.LENGTH_SHORT).show();
        }else{
        Intent intent = new Intent(this, ScreenData.class);
        intent.putExtra(SELECT_NAME, nameSSOO);
        intent.putExtra(SELECT_VERSION,data);
        startActivity(intent);
        }
    }
}
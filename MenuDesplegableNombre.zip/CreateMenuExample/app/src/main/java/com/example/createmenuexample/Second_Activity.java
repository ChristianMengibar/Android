package com.example.createmenuexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;


public class Second_Activity extends AppCompatActivity {

    public static final String SECOND_ACTIVITY_NAME = "second.activity.name";

    private Intent second;

    private Intent reivirMensaje;

    private TextView sc_tvIntroduceNombre,
            sc_tvMensajeOtro;

    private EditText sc_etNombreUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        init();
    }

    public void init() {
        second = new Intent(this, MainActivity.class);

        sc_tvMensajeOtro = (TextView) findViewById(R.id.sc_MensajeOtro);
        sc_etNombreUser = (EditText) findViewById(R.id.sc_etIntroduceNombre);
        sc_tvIntroduceNombre = (TextView) findViewById(R.id.sc_tvIntroduceNombre);

        second = new Intent(this, MainActivity.class);

        reivirMensaje = getIntent();

        String nameMain = reivirMensaje.getStringExtra(MainActivity.MAIN_ACTIVITY_NAME);
        sc_tvMensajeOtro.setText(nameMain);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.second_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.sc_menuVolver:

                String name = sc_etNombreUser.getText().toString();

                second.putExtra(SECOND_ACTIVITY_NAME, name);

                startActivity(second);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
package com.example.createmenuexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String MAIN_ACTIVITY_NAME = "main.activity.name";

    private Intent main;

    private Intent recivirMensaje;

    private TextView ma_tvIntroduceNombre,
            ma_tvMensajeOtro;

    private EditText ma_etNombreUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inti();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public void inti() {
        main = new Intent(this, Second_Activity.class);

        recivirMensaje = getIntent();

        ma_tvIntroduceNombre = (TextView) findViewById(R.id.ma_tvIntroduceNombre);
        ma_tvMensajeOtro = (TextView) findViewById(R.id.ma_tvMensajeOtro);

        ma_etNombreUser = (EditText) findViewById(R.id.ma_etNombreUser);


        String name = recivirMensaje.getStringExtra(Second_Activity.SECOND_ACTIVITY_NAME);

        ma_tvMensajeOtro.setText(name);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.ma_menu1:
                Toast.makeText(this, "Has pulsado la opcion de nuevo", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.ma_menu2:
                Toast.makeText(this, "Has selecionado eliminar", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.ma_menuSiguiente:
                String name = ma_etNombreUser.getText().toString();

                main.putExtra(MAIN_ACTIVITY_NAME, name);

                startActivity(main);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
package com.example.giblistview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    private EditText etNombre;
    private EditText etApellidos;
    private EditText etEdad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        etNombre = (EditText) findViewById(R.id.ma2_etNombre);
        etApellidos = (EditText) findViewById(R.id.ma2_edApellidos);
        etEdad = (EditText) findViewById(R.id.ma2_etEdad);
    }

    public void guardarDatos(View view) {
        if (etNombre.getText().toString().equals("")) {
            Toast.makeText(this, "Debes introducir un nombre.", Toast.LENGTH_SHORT).show();
        } else {
            Intent newIntent = new Intent(this, MainActivity3.class);
            SharedPreferences pref = getSharedPreferences("sharedConfiguration", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("Nombre", etNombre.getText().toString());
            editor.putString("Apellidos", etApellidos.getText().toString());
            editor.putString("Edad", etEdad.getText().toString());
            editor.commit();
            startActivity(newIntent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(Menu.NONE, 1, Menu.NONE, "Volver");
        menu.add(Menu.NONE, 2, Menu.NONE, "Guardar");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            case 2:
                Intent newIntent = new Intent(this, MainActivity3.class);
                SharedPreferences pref = getSharedPreferences("sharedConfiguration", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = pref.edit();
                editor.putString("Nombre", etNombre.getText().toString());
                editor.putString("Apellidos", etApellidos.getText().toString());
                editor.putString("Edad", etEdad.getText().toString());
                editor.commit();
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
package com.example.giblistview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView ma1_lvConsolas;
    private ArrayList<String> list = new ArrayList<>();
    private int counter;
    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ma1_lvConsolas = (ListView) findViewById(R.id.ma1_lvConsolas);
        registerForContextMenu(ma1_lvConsolas);
        list.add("Consolas");
        adapter = new ArrayAdapter<String>(this, R.layout.lista, R.id.lista_tvEstrella, list);
        ma1_lvConsolas.setAdapter(adapter);

        listClickView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nuevo:
                this.list.add("Nuevo " + (++counter));
                this.adapter.notifyDataSetChanged();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu2, menu);
        menu.add(Menu.NONE, 1, Menu.NONE, "Detalles");
        menu.add(Menu.NONE, 2, Menu.NONE, "Borrar");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case 1:
                Toast.makeText(this, "Has pinchado en tu seleccion.", Toast.LENGTH_SHORT).show();
                return true;
            case 2:
                this.list.remove(info.position);
                this.adapter.notifyDataSetChanged();
                Toast.makeText(this, "Seleccion eliminada correctamente.", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    public void listClickView() {
        ListView lv = findViewById(R.id.ma1_lvConsolas);
        Intent newIntent = new Intent(this, MainActivity2.class);
        TextView list = findViewById(R.id.lista_tvEstrella);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String option = adapterView.getItemAtPosition(i).toString();
                SharedPreferences pref = getSharedPreferences("sharedConfiguration", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = pref.edit();
                editor.putString("consolas", option);
                editor.commit();
                startActivity(newIntent);
            }
        });
    }
}
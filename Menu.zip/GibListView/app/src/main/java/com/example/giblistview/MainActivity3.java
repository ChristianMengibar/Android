package com.example.giblistview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    private TextView tvNombre;
    private TextView tvApellidos;
    private TextView tvEdad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        tvNombre = (TextView) findViewById(R.id.ma3_tvNombre);
        tvApellidos = (TextView) findViewById(R.id.ma3_tvAPellidos);
        tvEdad = (TextView) findViewById(R.id.ma3_tvEdad);

        SharedPreferences pref = getSharedPreferences("sharedConfiguration", Context.MODE_PRIVATE);

        String nombre = pref.getString("Nombre", "default");
        tvNombre.setText(nombre);

        String apellidos = pref.getString("Apellidos", "default");
        tvApellidos.setText(apellidos);

        String edad = pref.getString("Edad", "default");
        tvEdad.setText(edad);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(Menu.NONE, 1, Menu.NONE, "Volver");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}